﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banco__Proyecto_
{
    public class Cliente
    {
        private long NUM_CUENTA;
        private String Nombre;
        private String Edad;
        private String CURP;
        private String INE;
        private String Domicilio;
        private String Tel;
        private String Correo_E;
        private List<Tarjeta> Tarjetas;

        public Cliente()
        {
            NUM_CUENTA = 0;
            Nombre = "";
            Edad = "";
            CURP = "";
            INE = "";
            Domicilio = "";
            Tel = "";
            Correo_E = "";
            Tarjetas = new List<Tarjeta>();
        }

        public void setNUM_CUENTA(long num_cuenta)
        {
            NUM_CUENTA = num_cuenta;
        }

        public long getNUM_CUENTA()
        {
            return NUM_CUENTA;
        }

        public void setNombre(String nombre)
        {
            Nombre = nombre;
        }

        public String getNombre()
        {
            return Nombre;
        }

        public void setEdad(String edad)
        {
            Edad = edad;
        }

        public String getEdad()
        {
            return Edad;
        }

        public void setCURP(String curp)
        {
            CURP = curp;
        }

        public String getCURP()
        {
            return CURP;
        }

        public void setINE(String ine)
        {
            INE = ine;
        }

        public String getINE()
        {
            return INE;
        }

        public void setDomicilio(String domicilio)
        {
            Domicilio = domicilio;
        }

        public String getDomicilio()
        {
            return Domicilio;
        }

        public void setTel(String tel)
        {
            Tel = tel;
        }

        public String getTel()
        {
            return Tel;
        }

        public void setCorreo_E(String correo)
        {
            Correo_E = correo;
        }

        public String getCorreo_E()
        {
            return Correo_E;
        }

        public List<Tarjeta> getTarjetas()
        {
            return Tarjetas;
        }

        public void setTarjetas(List<Tarjeta> tarjetas)
        {
            Tarjetas = tarjetas;
        }
    }
}
