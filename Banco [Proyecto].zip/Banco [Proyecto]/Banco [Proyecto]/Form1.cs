﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Banco__Proyecto_
{
    public partial class Form1 : Form
    {
        private String ruta;
        private StreamWriter writer;
        private StreamReader reader;
        private List<Cliente> Clientes;
        private long NUM_CUENTA;
        private Cliente aux_c;

        public Form1()
        {
            InitializeComponent();
            ruta = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
                + "\\Banco.txt";
            Clientes = new List<Cliente>();
            NUM_CUENTA = 10000000;
            radioButton1.Select();
            cargar();
        }

        private void cargar()
        {
            try
            {
                reader = new StreamReader(ruta);
                String Line;
                Line = reader.ReadLine();
                while(Line != null)
                {
                    switch (Line)
                    {
                        case "//":
                            Line = reader.ReadLine();
                            NUM_CUENTA = long.Parse(Line);
                            Line = reader.ReadLine();
                            break;
                        case "*":
                            Cliente c = new Cliente();
                            Line = reader.ReadLine();
                            c.setNUM_CUENTA(long.Parse(Line));
                            Line = reader.ReadLine();
                            c.setNombre(Line);
                            Line = reader.ReadLine();
                            c.setEdad(Line);
                            Line = reader.ReadLine();
                            c.setCURP(Line);
                            Line = reader.ReadLine();
                            c.setINE(Line);
                            Line = reader.ReadLine();
                            c.setDomicilio(Line);
                            Line = reader.ReadLine();
                            c.setTel(Line);
                            Line = reader.ReadLine();
                            c.setCorreo_E(Line);

                            Line = reader.ReadLine();
                            while (Line == "+")
                            {
                                Tarjeta t = new Tarjeta();
                                Line = reader.ReadLine();
                                t.setNumTarjeta(Line);
                                Line = reader.ReadLine();
                                t.setSaldo(Double.Parse(Line));
                                Line = reader.ReadLine();
                                t.setTipo(int.Parse(Line));
                                Line = reader.ReadLine();
                                t.setNIP(int.Parse(Line));
                                Line = reader.ReadLine();
                                t.setCUV(int.Parse(Line));
                                Line = reader.ReadLine();
                                t.setClaveInter(Line);
                                c.getTarjetas().Add(t);
                                Line = reader.ReadLine();
                               
                            }
                            Clientes.Add(c);
                            break;
                    }
                }
                reader.Close();
                MessageBox.Show("Archivo cargado correctamente", "Archivo cargado", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch(Exception e)
            {
                MessageBox.Show("No se cargó ningún archivo: "+ e, "Error al cargar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void guardar()
        {
            try
            {
                writer = new StreamWriter(ruta);
                writer.WriteLine("//");
                writer.WriteLine(NUM_CUENTA);
                foreach (Cliente c in Clientes)
                {
                    writer.WriteLine("*");
                    writer.WriteLine(c.getNUM_CUENTA());
                    writer.WriteLine(c.getNombre());
                    writer.WriteLine(c.getEdad());
                    writer.WriteLine(c.getCURP());
                    writer.WriteLine(c.getINE());
                    writer.WriteLine(c.getDomicilio());
                    writer.WriteLine(c.getTel());
                    writer.WriteLine(c.getCorreo_E());

                    foreach (Tarjeta t in c.getTarjetas())
                    {
                        writer.WriteLine("+");
                        writer.WriteLine(t.getNumTarjeta());
                        writer.WriteLine(t.getSaldo());
                        writer.WriteLine(t.getTipo());
                        writer.WriteLine(t.getNIP());
                        writer.WriteLine(t.getCUV());
                        writer.WriteLine(t.getClaveInter());
                    }
                }
                writer.Close();
                MessageBox.Show("Archivo guardado correctamente", "Guardar archivo", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }catch(Exception e){
                MessageBox.Show("No se pudo guardar el archivo", "Error al guardar archivo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            

        }

        private void registrarCliente()
        {
            Cliente c = new Cliente();
            c.setNUM_CUENTA(NUM_CUENTA);
            c.setNombre(textBox1.Text);
            c.setEdad(textBox2.Text);
            c.setCURP(textBox3.Text);
            c.setINE(textBox4.Text);
            c.setDomicilio(textBox5.Text);
            c.setTel(textBox6.Text);
            c.setCorreo_E(textBox7.Text);
            Clientes.Add(c);
            MessageBox.Show("Cliente "+ c.getNUM_CUENTA() +" registrado con éxito", 
                "Registrar cliente", MessageBoxButtons.OK, MessageBoxIcon.Information);
            NUM_CUENTA++;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            guardar();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedIndex = 1;
            clear4();
            clear5();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedIndex = 2;
            clear3();
            clear5();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedIndex = 3;
            clear3();
            clear4();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            pintarAB();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            pintarTrinity();
        }

        private void pintarAB()
        {
            panel2.BackColor = panel7.BackColor;
            label1.BackColor = panel4.BackColor;
            label1.ForeColor = panel12.BackColor;
            panel1.BackColor = panel6.BackColor;
            button1.BackColor = panel12.BackColor;
            button1.ForeColor = panel4.BackColor;
            button2.BackColor = panel12.BackColor;
            button2.ForeColor = panel4.BackColor;
            button3.BackColor = panel12.BackColor;
            button3.ForeColor = panel4.BackColor;
            button4.BackColor = panel12.BackColor;
            button4.ForeColor = panel4.BackColor;
            button5.BackColor = panel12.BackColor;
            button5.ForeColor = panel4.BackColor;
            button6.BackColor = panel12.BackColor;
            button6.ForeColor = panel4.BackColor;
            button7.BackColor = panel12.BackColor;
            button7.ForeColor = panel4.BackColor;
            pictureBox1.BackColor = panel4.BackColor;
            label6.ForeColor = panel12.BackColor;
            label7.ForeColor = panel12.BackColor;
            label8.ForeColor = panel12.BackColor;
            label16.ForeColor = panel12.BackColor;
            tabPage2.BackColor = panel4.BackColor;
            tabPage2.ForeColor = panel12.BackColor;
            tabPage3.BackColor = panel4.BackColor;
            tabPage3.ForeColor = panel12.BackColor;
            tabPage4.BackColor = panel4.BackColor;
            tabPage4.ForeColor = panel12.BackColor;
            tabPage5.BackColor = panel4.BackColor;
            tabPage5.ForeColor = panel12.BackColor;
            tabPage6.BackColor = panel4.BackColor;
            tabPage6.ForeColor = panel12.BackColor;
            textBox1.ForeColor = panel12.BackColor;
            textBox2.ForeColor = panel12.BackColor;
            textBox3.ForeColor = panel12.BackColor;
            textBox4.ForeColor = panel12.BackColor;
            textBox5.ForeColor = panel12.BackColor;
            textBox6.ForeColor = panel12.BackColor;
            textBox7.ForeColor = panel12.BackColor;
        }

        private void pintarTrinity()
        {
            panel2.BackColor = panel9.BackColor;
            label1.BackColor = panel11.BackColor;
            label1.ForeColor = panel13.BackColor;
            panel1.BackColor = panel10.BackColor;
            button1.BackColor = panel13.BackColor;
            button1.ForeColor = panel11.BackColor;
            button2.BackColor = panel13.BackColor;
            button2.ForeColor = panel11.BackColor;
            button3.BackColor = panel13.BackColor;
            button3.ForeColor = panel11.BackColor;
            button4.BackColor = panel13.BackColor;
            button4.ForeColor = panel11.BackColor;
            button5.BackColor = panel13.BackColor;
            button5.ForeColor = panel11.BackColor;
            button6.BackColor = panel13.BackColor;
            button6.ForeColor = panel11.BackColor;
            button7.BackColor = panel13.BackColor;
            button7.ForeColor = panel11.BackColor;
            pictureBox1.BackColor = panel11.BackColor;
            label6.ForeColor = panel13.BackColor;
            label7.ForeColor = panel13.BackColor;
            label8.ForeColor = panel13.BackColor;
            label16.ForeColor = panel13.BackColor;
            tabPage2.BackColor = panel11.BackColor;
            tabPage2.ForeColor = panel13.BackColor;
            tabPage3.BackColor = panel11.BackColor;
            tabPage3.ForeColor = panel13.BackColor;
            tabPage4.BackColor = panel11.BackColor;
            tabPage4.ForeColor = panel13.BackColor;
            tabPage5.BackColor = panel11.BackColor;
            tabPage5.ForeColor = panel13.BackColor;
            tabPage6.BackColor = panel11.BackColor;
            tabPage6.ForeColor = panel13.BackColor;
            textBox1.ForeColor = panel13.BackColor;
            textBox2.ForeColor = panel13.BackColor;
            textBox3.ForeColor = panel13.BackColor;
            textBox4.ForeColor = panel13.BackColor;
            textBox5.ForeColor = panel13.BackColor;
            textBox6.ForeColor = panel13.BackColor;
            textBox7.ForeColor = panel13.BackColor;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (validarFormularioC())
            {
                registrarCliente();
            }
        }

        private Boolean validarFormularioC()
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" ||
                textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" ||
                textBox7.Text == "")
            {
                MessageBox.Show("Rellene los campos faltantes", "Formulario incompleto",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            else
            {
                return true;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl2.SelectedIndex = 4;
            clear3();
            clear4();
            clear5();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (validarFormularioT())
            {
                Cliente c = buscarCuenta(long.Parse(textBox8.Text));
                int NIP = int.Parse(textBox9.Text);
                int tipo = getTipoInt(comboBox1.Text);
                Double saldo = Double.Parse(textBox10.Text);
                if (c != null)
                {
                    if (tipo != 0)
                    {
                        if (valNuevoNIP(NIP))
                        {
                            if (valSaldo(tipo, saldo))
                            {
                                crearTarjeta(c, tipo, NIP, saldo);
                            }
                        }
                    }
                }
            }
        }

        private void crearTarjeta(Cliente c, int tipo, int nip, Double saldo)
        {
            Random random = new Random();
            Tarjeta t = new Tarjeta();
            t.setNumTarjeta("" + random.Next(100000, 999999) + c.getNUM_CUENTA() + "1");
            t.setTipo(tipo);
            t.setNIP(nip);
            t.setSaldo(saldo);
            t.setCUV(random.Next(100, 999));
            t.setClaveInter("" + random.Next(100000, 999999) + c.getNUM_CUENTA() + "1");
            c.getTarjetas().Add(t);
            MessageBox.Show("Tarjeta creada con éxito.", "Tarjeta creada", MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            label21.Text = "Numero de Tarjeta: " + t.getNumTarjeta() + "\n" + "Saldo inicial: $" + t.getSaldo() + "\n"
               + "Tipo: " + t.getTipoS() + "\n" + "NIP: " + t.getNIP() + "\n" + "CUV: " + t.getCUV() + "\n"
               + "Clave Interbancaria: " + t.getClaveInter();

        }

        private Boolean valSaldo(int tipo, Double saldo)
        {
            switch (tipo)
            {
                case 1:
                    if (saldo >= 1000 && saldo <= 50000)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Sólo se puede inicar con un saldo entre $1000 y $50000.", 
                            "Saldo inválido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                case 2:
                    if (saldo >= 500 && saldo <= 10000)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Sólo se puede inicar con un saldo entre $500 y $10000.", 
                            "Saldo inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                case 3:
                    if (saldo >= 100 && saldo <= 5000)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Sólo se puede inicar con un saldo entre $100 y $5000.", 
                            "Saldo inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                case 4:
                    if (saldo >= 100 && saldo <= 5000)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Sólo se puede inicar con un saldo entre $100 y $5000.",
                            "Saldo inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return false;
                    }
                default: return false;


            }
        }

        private int getTipoInt(String s)
        {
            switch (s)
            {
                case "Oro": return 1;
                case "Plata": return 2;
                case "Bronce": return 3;
                case "Junior": return 4;
                default: return 0;
            }
        }

        private Boolean valNuevoNIP(int NIP)
        {
            if(NIP <= 9999 && NIP >= 1000)
            {
                return true;
            }
            else
            {
                MessageBox.Show("Escriba un NIP de 4 dígitos", "NIP inválido",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        private Cliente buscarCuenta(long nc)
        {
            Cliente C = new Cliente();
            Boolean f = false;
            foreach(Cliente c in Clientes)
            {
                if(c.getNUM_CUENTA() == nc)
                {
                    f = true;
                    C = c;
                }
            }

            if (f == true)
            {
                return C;
            }
            else
            {
                MessageBox.Show("Escriba un número de cuenta válido", "Cuenta no encontrada",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return null;
            }
        }

        private Boolean validarFormularioT()
        {
            if(textBox8.Text == "" || comboBox1.Text == "" || textBox9.Text == "" || textBox10.Text == "")
            {
                MessageBox.Show("Rellene los campos faltantes", "Formulario incompleto",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            else
            {
                return true;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            comboBox1.Text = "";
            textBox9.Clear();
            textBox10.Clear();
            label21.Text = "";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label23.Text = "";
            listBox1.Items.Clear();
            label24.Text = "Seleccione una tarjeta";
            if(textBox11.Text != "")
            {
                aux_c = buscarCuenta(long.Parse(textBox11.Text));
                if(aux_c != null)
                {
                    label23.Text = "Nombre: " + aux_c.getNombre() + "\n" + "Edad: " + aux_c.getEdad() 
                        + "\n" + "CURP: " + aux_c.getCURP() + "\n" + "INE: " + aux_c.getINE() + "\n" 
                        + "Domicilio: " + aux_c.getDomicilio() + "\n" + "Teléfono: " + aux_c.getTel() 
                        + "\n" + "Correo: " + aux_c.getCorreo_E();
                    foreach(Tarjeta t in aux_c.getTarjetas())
                    {
                        listBox1.Items.Add(t.getTipoS() + " - " + t.getNumTarjeta());
                    }
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String nc = "";
            String line = listBox1.Text;
            for(int i = 0; i < line.Length; i++)
            {
                switch (line[i])
                {
                    case '-':
                        i += 2;
                        for(int j = i; j < line.Length; j++)
                        {
                            nc = nc + line[j];
                            i = j;
                        }
                        
                        break;
                }
            }
            Tarjeta t = buscarTarjeta(aux_c, nc);
            label24.Text = "Saldo: $" + t.getSaldo() + "\n" + "NIP: " + t.getNIP() + "\n"
                + "CUV: " + t.getCUV() + "\n" + "Clave interbancaria: \n" + t.getClaveInter();
        }
        
        private Tarjeta buscarTarjeta(Cliente c,String nc)
        {
            Tarjeta T = new Tarjeta();
            Boolean f = false;
            foreach(Tarjeta t in c.getTarjetas())
            {
                if(t.getNumTarjeta().Equals(nc))
                {
                    f = true;
                    T = t;
                }
            }
            if (f)
            {
                return T;
            }
            else
            {
                return null;
            }
        }

        private void clear5()
        {
            textBox11.Clear();
            label23.Text = "";
            label24.Text = "Seleccione una tarjeta";
            listBox1.Items.Clear();

        }

        private void clear4()
        {
            textBox8.Clear();
            comboBox1.Text = "";
            textBox9.Clear();
            textBox10.Clear();
            label21.Text = "";
        }

        private void clear3()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
        }
    }
}
