﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banco__Proyecto_
{
    public class Tarjeta
    {
        private String NumTarjeta;
        private Double Saldo;
        private int Tipo;
        private int NIP;
        private int CUV;
        private String ClaveInter;

        public Tarjeta()
        {
            NumTarjeta = "";
            Saldo = 0;
            Tipo = 0;
            NIP = 0;
            CUV = 0;
            ClaveInter = "";
        }

        public void setNumTarjeta(String NT) => NumTarjeta = NT;
        public String getNumTarjeta() => NumTarjeta;
        public void setSaldo(Double S) => Saldo = S;
        public Double getSaldo() => Saldo;
        public void setTipo(int T) => Tipo = T;
        public int getTipo() => Tipo;
        public void setNIP(int N) => NIP = N;
        public int getNIP() => NIP;
        public void setCUV(int C) => CUV = C;
        public int getCUV() => CUV;
        public void setClaveInter(String CI) => ClaveInter = CI;
        public String getClaveInter() => ClaveInter;
        public String getTipoS()
        {
            switch (Tipo)
            {
                case 1: return "Oro";
                case 2: return "Plata";
                case 3: return "Bronce";
                case 4: return "Junior";
            }
            return "";
        }
    }
}
