﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ATM
{
    public partial class Form1 : Form
    {
        private StreamReader reader;
        private StreamWriter writer;
        private List<Cliente> Clientes;
        private long NUM_CUENTA;
        private String ruta;
        private Cliente C;
        private Tarjeta T;
        private int Intentos = 0;
        private Double cantidad;
        private int op;
        private int cmsn;

        public Form1()
        {
            InitializeComponent();
            Clientes = new List<Cliente>();
            ruta = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
                + "\\Banco.txt";
            cargar();
        }

        private void cargar()
        {
            try
            {
                reader = new StreamReader(ruta);
                String Line;
                Line = reader.ReadLine();
                while (Line != null)
                {
                    switch (Line)
                    {
                        case "//":
                            Line = reader.ReadLine();
                            NUM_CUENTA = long.Parse(Line);
                            Line = reader.ReadLine();
                            break;
                        case "*":
                            Cliente c = new Cliente();
                            Line = reader.ReadLine();
                            c.setNUM_CUENTA(long.Parse(Line));
                            Line = reader.ReadLine();
                            c.setNombre(Line);
                            Line = reader.ReadLine();
                            c.setEdad(Line);
                            Line = reader.ReadLine();
                            c.setCURP(Line);
                            Line = reader.ReadLine();
                            c.setINE(Line);
                            Line = reader.ReadLine();
                            c.setDomicilio(Line);
                            Line = reader.ReadLine();
                            c.setTel(Line);
                            Line = reader.ReadLine();
                            c.setCorreo_E(Line);

                            Line = reader.ReadLine();
                            while (Line == "+")
                            {
                                Tarjeta t = new Tarjeta();
                                Line = reader.ReadLine();
                                t.setNumTarjeta(Line);
                                Line = reader.ReadLine();
                                t.setSaldo(Double.Parse(Line));
                                Line = reader.ReadLine();
                                t.setTipo(int.Parse(Line));
                                Line = reader.ReadLine();
                                t.setNIP(int.Parse(Line));
                                Line = reader.ReadLine();
                                t.setCUV(int.Parse(Line));
                                Line = reader.ReadLine();
                                t.setClaveInter(Line);
                                c.getTarjetas().Add(t);
                                Line = reader.ReadLine();

                            }
                            Clientes.Add(c);
                            break;
                    }
                }
                reader.Close();
                MessageBox.Show("Archivo cargado correctamente", "Archivo cargado", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception e)
            {
                MessageBox.Show("No se cargó ningún archivo: " + e, "Error al cargar", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
        }

        private void guardar()
        {
            try
            {
                writer = new StreamWriter(ruta);
                writer.WriteLine("//");
                writer.WriteLine(NUM_CUENTA);
                foreach (Cliente c in Clientes)
                {
                    writer.WriteLine("*");
                    writer.WriteLine(c.getNUM_CUENTA());
                    writer.WriteLine(c.getNombre());
                    writer.WriteLine(c.getEdad());
                    writer.WriteLine(c.getCURP());
                    writer.WriteLine(c.getINE());
                    writer.WriteLine(c.getDomicilio());
                    writer.WriteLine(c.getTel());
                    writer.WriteLine(c.getCorreo_E());

                    foreach (Tarjeta t in c.getTarjetas())
                    {
                        writer.WriteLine("+");
                        writer.WriteLine(t.getNumTarjeta());
                        writer.WriteLine(t.getSaldo());
                        writer.WriteLine(t.getTipo());
                        writer.WriteLine(t.getNIP());
                        writer.WriteLine(t.getCUV());
                        writer.WriteLine(t.getClaveInter());
                    }
                }
                writer.Close();
                MessageBox.Show("Archivo guardado correctamente", "Guardar archivo", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception e)
            {
                MessageBox.Show("No se pudo guardar el archivo", "Error al guardar archivo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }

        private void label4_Click(object sender, EventArgs e)
        {
            String nt = textBox1.Text;
            if(nt.Length == 15)
            {
                C = buscarCuenta(obtenerNumCuenta(nt));
                if (C != null)
                {
                    T = buscarTarjeta(C, nt);
                    if (T != null)
                    {
                        if ("" + T.getNIP() == textBox2.Text)
                        {
                            setComision(T.getTipo());
                            label24.Text = label24.Text + "\n\n\nSE COBRARAN $" + cmsn
                             + " DE COMISION";
                            tabControl1.SelectedIndex = 1;
                            label9.Text = label9.Text + "\n\n\nBIENVENID@ " + C.getNombre();
                        }
                        else
                        {
                            Intentos++;
                            label6.Text = "NIP INCORRECTO\nQUEDAN " + (3 - Intentos) + " INTENTOS";
                        }
                    }
                }
                else
                {
                    label6.Text = "TARJETA INEXISTENTE";
                }
                if (Intentos > 3)
                {
                    Close();
                }
            }
            else
            {
                label6.Text = "EL NUMERO DE TARJETA\nDEBE DE TENER\n15 DIGITOS";
            }
        }

        private long obtenerNumCuenta(String nc)
        {
            String s = "";
            for (int i = 6; i < 14; i++)
            {
                s = s + nc[i];
            }
            return long.Parse(s);
        }

        private Tarjeta buscarTarjeta(Cliente c, String nc)
        {
            Tarjeta T = new Tarjeta();
            Boolean f = false;
            foreach (Tarjeta t in c.getTarjetas())
            {
                if (t.getNumTarjeta().Equals(nc))
                {
                    f = true;
                    T = t;
                }
            }
            if (f)
            {
                return T;
            }
            else
            {
                return null;
            }
        }

        private Cliente buscarCuenta(long nc)
        {
            Cliente C = new Cliente();
            Boolean f = false;
            foreach (Cliente c in Clientes)
            {
                if (c.getNUM_CUENTA() == nc)
                {
                    f = true;
                    C = c;
                }
            }

            if (f == true)
            {
                return C;
            }
            else
            {
                return null;
            }
        }
        private void label3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 3;
        }

        private void label21_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label20_Click(object sender, EventArgs e)
        {
            cantidad = Double.Parse(textBox3.Text);
            
            if (valCantidad(T.getTipo(), cantidad))
            {
                tabControl1.SelectedIndex = 4;

            }

        }

        private void setComision(int tipo)
        {
            switch (tipo)
            {
                case 1: cmsn = 15; break;
                case 2: cmsn = 10; break;
                case 3: cmsn = 5; break;
                case 4: cmsn = 5; break;
            }
        }
        private Boolean valCantidad(int tipo, Double cantidad)
        {
            switch (tipo)
            {
                case 1:
                    if (cantidad >= 1000 && cantidad <= 50000)
                    {
                        return true;
                    }
                    else
                    {
                        label22.Text = "ESCRIBA UNA CANTIDAD ENTRE $1000 Y $50000";
                        return false;
                    }
                case 2:
                    if (cantidad >= 500 && cantidad <= 10000)
                    {
                        return true;
                    }
                    else
                    {
                        label22.Text = "ESCRIBA UNA CANTIDAD ENTRE $500 Y $10000";
                        return false;
                    }
                case 3:
                    if (cantidad >= 100 && cantidad <= 5000)
                    {
                        return true;
                    }
                    else
                    {
                        label22.Text = "ESCRIBA UNA CANTIDAD ENTRE $100 Y $5000";                        return false;
                    }
                case 4:
                    if (cantidad >= 100 && cantidad <= 5000)
                    {
                        return true;
                    }
                    else
                    {
                        label22.Text = "ESCRIBA UNA CANTIDAD ENTRE $100 Y $5000";
                        return false;
                    }
                default: return false;


            }
        }

        private void label16_Click(object sender, EventArgs e)
        {
            cantidad = 100;
            tabControl1.SelectedIndex = 4;
        }

        private void label15_Click(object sender, EventArgs e)
        {
            cantidad = 500;
            tabControl1.SelectedIndex = 4;
        }

        private void label18_Click(object sender, EventArgs e)
        {
            cantidad = 1500;
            tabControl1.SelectedIndex = 4;
        }

        private void label17_Click(object sender, EventArgs e)
        {
            cantidad = 1000;
            tabControl1.SelectedIndex = 4;
        }

        private void label26_Click(object sender, EventArgs e)
        {
            realizarOperacion();
            tabControl1.SelectedIndex = 5;
        }

        private void realizarOperacion()
        {
            switch (op)
            {
                case 1:
                    T.setSaldo(T.getSaldo() - cantidad - cmsn);
                    label23.Text = label23.Text + "\n\n\nSE RETIRARON $" + cantidad + "\n" +
                        "SALDO ACTUAL: $" + T.getSaldo();
                    break;
                case 2:
                    T.setSaldo(T.getSaldo() + cantidad - cmsn);
                    label23.Text = label23.Text + "\n\n\nSE DEPOSITARON $" + cantidad + "\n" +
                        "SALDO ACTUAL: $" + T.getSaldo();
                    break;
                case 3:
                    T.setSaldo(T.getSaldo() - cmsn);
                    label23.Text = label23.Text + "\n\n\nSALDO $" + T.getSaldo();
                    break;
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            op = 1;
            tabControl1.SelectedIndex = 2;
        }

        private void label10_Click(object sender, EventArgs e)
        {
            op = 2;
            tabControl1.SelectedIndex = 2;
        }

        private void label11_Click(object sender, EventArgs e)
        {
            op = 3;
            tabControl1.SelectedIndex = 4;
        }

        private void label27_Click(object sender, EventArgs e)
        {
            guardar();
            Close();
        }
    }
}
